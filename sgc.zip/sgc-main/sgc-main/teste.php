<?php
    $nome = $_POST['nome'];

    echo $nome;
?>