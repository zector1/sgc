<?php
    $nome = 'gabriel';
?>
<style>
@import url("https://fonts.googleapis.com/css2?family=Nokora&family=Public+Sans&display=swap");
</style>
<body>
<table width="100%" cellpadding="0" cellspacing="0">
    <table width="600px" cellpadding="0" cellspacing="0" align="center">
        <tr>
            <td style="padding: 40px 0 0px 0;" align="center">
                <img src="cid:banner_sistema" alt="Imagem do SGC">
            </td>
        </tr>
    <tr>
        <td style="padding: 20px 50px 0px 20px; text-align: left;" align="left" >
            <h1 style="font-family: 'Nokora', sans-serif; font-size: 1.5em; display: inline; color: #405F9E;">Bem-vindo(a) ao SGC!</h1> 
        </td>
    </tr>
    <tr>
        <td style="padding:0px 20px 160px 20px;">
            <p style="font-family: 'Nokora', sans-serif; padding: 0px">
                Olá, <?php echo $nome?><br>
                O seu cadastro foi efetuado com sucesso. Por favor, Siga as próximas orientações do administrador da portaria.</p>
            </td>
        </tr>
        <tr>
            <td style="padding: 10px 10px 10px 10px;" bgcolor="#D9DCE1">
                <p style="text-align: center; font-family: 'public-sans', sans-serif;">© 2022 IFBA., Inc. Todos os direitos reservados</p> 
            </td>
        </tr>
    </table>    
</table>
</body>
