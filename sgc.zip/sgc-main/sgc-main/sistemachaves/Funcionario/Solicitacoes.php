<?php

include_once('PHP/Agendar/postAgendar.php');
include_once('PHP/Conexao.php');
include_once('PHP/Agendar/InsertAgendar.php');
include_once('PHP/Agendar/agendar.php');

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SGC - CADASTRO</title>
    <!-- CSS GLOBAL -->
    <link href='./CSS/GLOBAL/Tab_Bar.css' rel='stylesheet'>
    <!-- CSS -->
    <link href="./CSS/solicitacoes.css" rel="stylesheet" type="text/css" />
    <!-- JAVASCRIPT GLOBAL -->
    <script src="./JS/" type="text/javascript" defer></script>
    <!-- JAVASCRIPT -->
    <script src="JS/agendamento.js" defer></script>
    <script src="JS/popSala.js" defer></script>
    <script src="JS/sala.js" defer></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="../Funcionario/JS/HOME/Ajax_Insert_Home_User.js" type="text/javascript" defer></script>
    <!-- CSS ASSETS -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href='../Funcionario/CSS/Fonts.css' rel='stylesheet'>
</head>
<body>
    <div class="indicador1">
        <div>
            <i class='bx bx-chevron-left'></i>
            <i class='bx bx-chevron-left'></i>
        </div>
    </div>
    <!-- POPUPS -->

    <header class="Header">
        <!-- Barra Laterial -->
        <nav class="Nav">
            <!-- Logo SGC -->
            <div class="Logo_SGC">
                <!-- Logo SGC -->
                <div>
                    <img src="../Assets/Logo 1.png" alt="Logo SGC">
                    <span>Sistema de Gerenciamento de Chaves</span>
                </div>
                <!-- Alternativa Logo SGC -->
                <div>
                    <img src="../Assets/Chave.png" alt="Logo SGC">
    
                </div>  
            </div>
            <!-- Container Com Opções da Barra Lateral -->
            <div class="Container_Opc">
                <!-- Lista dos Itens -->
                <ul class="Ul_Barra">
                    <!-- Item 1 = Home -->
                    <li class="Li_Barra">
                        <a href="../Funcionario/Home.php" class="Item_Barra">
                            <div class="Div_Item_Barra">
                                <i class='bx bx-home'></i>
                            </div>
                            <span class="Name_Item_Barra Status1">Home</span>
                        </a>
                    </li>
                    <!-- Item 2 = Cadastro -->
                    <li class="Li_Barra">
                        <a href="../Funcionario/Gerenciamento.php" class="Item_Barra">
                            <div class="Div_Item_Barra">
                                <i class='bx bxs-key'></i>
                            </div>
                            <span class="Name_Item_Barra Status1">Gerenciamento</span>
                        </a>
                    </li>
                    <!-- Item 3 = Pendetes -->
                    <li class="Li_Barra">
                        <a href="../Funcionario/Pendente.php" class="Item_Barra">
                            <div class="Div_Item_Barra">
                                <i class='bx bx-time-five'></i>
                            </div>
                            <span class="Name_Item_Barra Status1">Pendente</span>
                        </a>
                    </li>
                    <!-- Item 4 = Solicitações -->
                    <li class="Li_Barra">
                        <a href="../Funcionario/Solicitacoes.php" class="Item_Barra active">
                            <div class="Div_Item_Barra">
                                <i class='bx bx-archive-in'></i>
                            </div>
                            <span class="Name_Item_Barra Status1">Solicitações</span>
                        </a>
                    </li>
                    <!-- Item 5 = Agendamento -->
                    <li class="Li_Barra">
                        <a href="../Funcionario/Agendamento.php" class="Item_Barra">
                            <div class="Div_Item_Barra">
                                <i class='bx bx-bell'></i>
                            </div>
                            <span class="Name_Item_Barra Status1">Agendamento</span>
                        </a>
                    </li>
                    <!-- Item 6 = Sobre -->
                    <li class="Li_Barra">
                        <div></div>
                        <a href="#" class="Item_Barra">
                            <div class="Div_Item_Barra">
                                <i class='bx bxs-group'></i>
                            </div>
                            <span class="Name_Item_Barra Status1">Sobre</span>
                        </a>
                    </li>
                    <!-- Item 7 = Sair -->
                    <li class="Li_Barra">
                        <a href="../config/logout.php" class="Item_Barra_Sair">
                            <i class='bx bx-exit'></i>
                        </a>
                    </li>
                </ul>
            </div>
        </nav> 
        <!-- Indicadores do Status da Barra Lateral -->
            <div class="indicadores">
                <div class="indicador2"></div>
            </div>
    </header>
    <main class="Main">
        <!-- Bloco com Nome do Usuário -->
        <div class="Main_Cont1">
        <i class='bx bx-chevron-right' ></i>
            <h3>Solicitações de chaves</h3>
        </div>
        <!-- Bloco com Predios -->
        
           

                    <?php
      
      $agendars = getAgendamentosSolicitados();
       foreach ($agendars as $agendar) {

        // echo "<div class=\"Main_Cont2\">";
        echo "<section class=\"chaves-agendadas\">";
        echo "<section class=\"chaves-agendadas\">";
        echo "<div class=\"container-pendente\">";
        echo "<img src=\"../Assets/Chave.png\" alt=\"chave do container\">";
        echo "<div class=\"linha-horizontal\"></div>";
        echo "<div class=\"informacoes-pendente\">";


         echo "<p>Requisição de: " . $agendar->nome . "</p>";
         echo "<p>Local: ". $agendar->descricao . "</p>";
         echo "<p>Data de emissão: ". $agendar->data_agendar . "</p>";
         echo "<p>Horário de início: ". $agendar->horario_inicio_agendar . "</p>";
         echo "<p>Horário de término: ". $agendar->horario_final_agendar . "</p>";
         echo "</div>";


        echo "<div class=\"linha-horizontal\"></div>";
        echo "<div class=\"botao-chave\" onclick=\"receberChave()\">";
        echo "<button class=\"chave-recebida\">Aprovar</button>";
        echo "<i class='bx bx-check-circle'></i>";
        echo "</div>";
        
        echo "<div class=\"botao-chave\" onclick=\"recusarAgendamento()\">";
        echo "<button class=\"chave-recebida\">Recusar</button>";
        echo "<img src=\"../img/close-icon.svg\" alt=\"recusar\">";
        echo "</div>";
        echo "</div>";
        echo "</section>";
        

       }
       ?>
            
            


        </div>
        <!-- Bloco com Chaves -->
        <div class="Main_Cont3">
            
        </div>
    </main>
</body>
</html>

