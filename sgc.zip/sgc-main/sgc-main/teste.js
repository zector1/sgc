var botaoalt1 = document.querySelector('#enviar_alteracao1');
var pop_novachave = document.querySelector('.POPUPS');
var Fecha_pop_up_X = document.querySelector('#Fecha_pop_up_X');

//pop_novachave.style.display = 'flex';

function abrirFormNovaChave(){
    pop_novachave.style.display = 'flex';
}

// botaoalt1.addEventListener('submit', abrirFormNovaChave);

// Fecha_pop_up_X.addEventListener('click', (evt)=>{
//     evt.preventDefault();
//     pop_novachave.style.display = 'none';  	
// });